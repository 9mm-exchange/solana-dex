export const SEED_CONFIG = "config";
export const SEED_BONDING_CURVE = "bonding-curve";
export const SEED_FAIR_MINT = "fair-mint";
export const SEED_COLLECTION = "collection";
export const SEED_ESCROW = "escrow";
